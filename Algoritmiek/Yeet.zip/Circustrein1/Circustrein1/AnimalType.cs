﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Circustrein1
{
    public enum AnimalType
    {
        Herbivore = 0,
            Carnivore = 1
    }
}
