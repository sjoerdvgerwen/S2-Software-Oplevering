﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace Circustrein1
{
    public enum AnimalSize
    {
        Small = 1,
        Medium = 3,
        Large = 5
    }
}
