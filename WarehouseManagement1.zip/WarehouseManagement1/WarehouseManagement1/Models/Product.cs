﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace WarehouseManagement1.Models
{
    public class Product
    {
        public int ProductID { get; set; }

        public int ProductQuantity { get; set; }

        public int ProductDescription { get; set; }

        public int ProductName { get; set; }

        public void modifyProduct()
        {

        }

        public void addProduct()
        {

        }

        public void deleteProduct()
        {

        }
    }
}
