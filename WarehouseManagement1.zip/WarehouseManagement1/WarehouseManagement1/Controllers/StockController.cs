﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WarehouseManagement1.Data;
using WarehouseManagement1.Models;

namespace WarehouseManagement1.Controllers
{
    public class StockController : Controller
    {

        private readonly ApplicationDbContext _dbContext;

        public StockController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }


        public IActionResult StockList()
        {
            var stock = new Stock() { Name = "Moersleutel", Id = 1 };

            return View(stock); 
        }

        public IActionResult Test()
        {
            var user1 = _dbContext.Stocks.First<>
            return Ok;
        }

        
    }
}
